# Data availability

Only the methylation output is available for now 
https://drive.google.com/file/d/1PtKq60WBDm34sVa-PNU8USJxOXXdo_De/view?usp=sharing